# tour-plan
Hi, it's my work on course by Artem islamov "Web-Start". 
In this work using: HTML5, css(Sass, Scss), JS. 
Adaptive for mobile displays and Desktop.

